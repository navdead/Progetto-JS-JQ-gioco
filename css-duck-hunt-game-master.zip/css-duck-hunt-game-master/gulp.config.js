const paths = {
	build: './build/',
	source: './src/'
};

module.exports = paths;