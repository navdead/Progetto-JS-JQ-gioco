var spazioDiGioco = document.getElementById("canvas");
var ContestoDiSpazioDiGioco = spazioDiGioco.getContext("2d");

//dichiarazione immagini

var fileIp = new Image();
var backGround = new Image();
var terreno = new Image();
var interferenzaSoffito = new Image();
var interfenrenzaPavimento = new Image();

fileIp.src = "images/pacchettoIp.png";
backGround.src = "images/background.png";
terreno.src = "images/terreno.png";
interferenzaSoffito.src = "images/muroTetto.png"; 
interfenrenzaPavimento.src = "images/muroPavimento.png";


//variabili per distanze

var spazio = 80;
var constant;

var pacchettoX = 10;
var pacchettoY = 150;

var gravity = 1.5;

var score = 0;

// audio files

var voloSuono = new Audio();
var AvanzamentoPunteggio = new Audio();

voloSuono.src = "./sounds/fly.mp3";
AvanzamentoPunteggio.src = "./sounds/score.mp3";

// on key down

document.addEventListener("keydown",salta);

function salta(){
    pacchettoY -= 25;
    voloSuono.play();
}

// coordinate muro

var muro = [];

muro[0] = {
    x : spazioDiGioco.width,
    y : 0
};

// animazioni

function animazioni(){
    
    ContestoDiSpazioDiGioco.drawImage(backGround,0,0);
    
    
    for(var i = 0; i < muro.length; i++){
        
        constant = interferenzaSoffito.height+spazio;
        ContestoDiSpazioDiGioco.drawImage(interferenzaSoffito,muro[i].x,muro[i].y);
        ContestoDiSpazioDiGioco.drawImage(interfenrenzaPavimento,muro[i].x,muro[i].y+constant);
             
        muro[i].x--;
        
        if( muro[i].x == 125 ){
            muro.push({
                x : spazioDiGioco.width,
                y : Math.floor(Math.random()*interferenzaSoffito.height)-interferenzaSoffito.height
            }); 
        }

        // rileva collisione pavimento o muro
        
        if( pacchettoX + fileIp.width >= muro[i].x && pacchettoX <= muro[i].x + interferenzaSoffito.width && (pacchettoY <= muro[i].y + interferenzaSoffito.height || pacchettoY+fileIp.height >= muro[i].y+constant) || pacchettoY + fileIp.height >=  spazioDiGioco.height - terreno.height){
            location.reload(); // ricarica la pagina
        }
        
        if(muro[i].x == 5){
            score++;
            AvanzamentoPunteggio.play();
        }
        
        
    }

    ContestoDiSpazioDiGioco.drawImage(terreno,0,spazioDiGioco.height - terreno.height);
    
    ContestoDiSpazioDiGioco.drawImage(fileIp,pacchettoX,pacchettoY);
    
    pacchettoY += gravity;

    ContestoDiSpazioDiGioco.font='40pt Calibri'
    ContestoDiSpazioDiGioco.fillStyle = 'white';
    ContestoDiSpazioDiGioco.fillText("Score : "+score,10,spazioDiGioco.height-20);
    
    requestAnimationFrame(animazioni);
    
}

animazioni();