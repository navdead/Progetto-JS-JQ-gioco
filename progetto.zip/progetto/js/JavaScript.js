alert("ciao");
function nascosto() {
    document.getElementById("prova").innerHTML = "boooo";
}