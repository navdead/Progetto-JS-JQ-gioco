var spazioDiGioco = document.getElementById("canvas");
var ContestoDiSpazioDiGioco = spazioDiGioco.getContext("2d");

//dichiarazione immagini
var fileIp = new Image();
var backGround = new Image();
var terreno = new Image();
var interferenzaSoffito = new Image();
var interfenrenzaPavimento = new Image();
var frame1 = new Image();

fileIp.src = "images/pacchettoIp.png";
backGround.src = "images/background.png";
terreno.src = "images/terreno.png";
interferenzaSoffito.src = "images/muroTetto.png";
interfenrenzaPavimento.src = "images/muroPavimento.png";
frame1.src = "images/frame1.png";

//variabili per distanze
var spazio = 180;
var pacchettoX = 10;
var pacchettoY = 150;

//sccore
var score = 0;

//booleane per gestire eventi
var saltoInCorso = false;
var siPuoContinure = true;

// audio files
var voloSuono = new Audio();
var AvanzamentoPunteggio = new Audio();
var errore = new Audio();
var score10 = new Audio();

voloSuono.src = "./sounds/fly.mp3";
AvanzamentoPunteggio.src = "./sounds/score.mp3";
errore.src = "./sounds/error.mp3";
score10.src = "./sounds/score10.mp3";

// variabbili di appoggio
var p;
var constant;

// variabili per animazioni
var altezzaSalto = 30; // altezza massima del salto
var velocitaSalto = 5; // velocita  di salto
var gravity = 1.5;// velocita di discesa

// coordinate muro e settaggio array
var muro = [];

// definizione del muro iniziale
muro[0] = {
    x: spazioDiGioco.width,
    y: -300
};

// on key down
document.addEventListener("keydown", salta);
document.addEventListener("keydown", cambia);

function cambia() {
    saltoInCorso = true;
    setTimeout(ritornoAnimazione, 80);
}

function ritornoAnimazione() {
    saltoInCorso = false;
}

// controllo animazione e settaggio del variabile d'apoggio
function salta() {
    if (siPuoContinure) {
        p = pacchettoY;
        saltoAnimazione();
    }
}

function saltoAnimazione() {
    if (pacchettoY > p - altezzaSalto) {
        ContestoDiSpazioDiGioco.drawImage(frame1, pacchettoX, pacchettoY);
        pacchettoY -= velocitaSalto;
        requestAnimationFrame(saltoAnimazione);
    }
    voloSuono.play();
}

// animazioni
function animazioni() {

    if (siPuoContinure) {
        // disegna lo sfondo
        ContestoDiSpazioDiGioco.drawImage(backGround, 0, 0);

        for (var i = 0; i < muro.length; i++) {
            constant = interferenzaSoffito.height + spazio;
            ContestoDiSpazioDiGioco.drawImage(interferenzaSoffito, muro[i].x, muro[i].y);
            ContestoDiSpazioDiGioco.drawImage(interfenrenzaPavimento, muro[i].x, muro[i].y + constant);
            //scorrimento muro
            muro[i].x--;

            //creazione muro
            if (muro[i].x == 500) {
                muro.push({
                    x: spazioDiGioco.width,
                    y: Math.floor(Math.random() * (interferenzaSoffito.height - 300)) - interferenzaSoffito.height //per creare delle coordinate negative fuori dal canvas
                });
            }

            // rileva collisione pavimento o muro
            if (pacchettoX + fileIp.width >= muro[i].x /*collisione contro il muro*/ &&
                pacchettoX <= muro[i].x + interferenzaSoffito.width /*non sta atraversndo il spazio di apertura*/ &&
                (pacchettoY <= muro[i].y + interferenzaSoffito.height || pacchettoY + fileIp.height >= muro[i].y + constant /* per vedere da quale parte delle interferenza sta*/) ||
                pacchettoY + fileIp.height >= spazioDiGioco.height - terreno.height /*collisione terreno*/) {
                errore.play();
                siPuoContinure = false;
                setTimeout(ricaricaPagina, 1500);
            }

            // gestione score
            if (muro[i].x == 5) {
                if (score % 10 == 0 && score != 0) {
                    score++;
                    score10.play();
                }
                else {
                    score++;
                    AvanzamentoPunteggio.play();
                }
            }
        }

        //controllo se il salto è in corso se no, si può disegnare l'animazione noramale
        if (saltoInCorso == false) {
            ContestoDiSpazioDiGioco.drawImage(fileIp, pacchettoX, pacchettoY);
        }

        //generazione della gravita
        pacchettoY += gravity;

        // disegno terreno
        ContestoDiSpazioDiGioco.drawImage(terreno, 0, spazioDiGioco.height - terreno.height);

        //css score
        ContestoDiSpazioDiGioco.font = '40pt Calibri'
        ContestoDiSpazioDiGioco.fillStyle = 'white';
        ContestoDiSpazioDiGioco.fillText("Score : " + score, 10, spazioDiGioco.height - 20);

        requestAnimationFrame(animazioni);
    }
}

function ricaricaPagina() {
    location.reload(); // ricarica la pagina
}
animazioni();